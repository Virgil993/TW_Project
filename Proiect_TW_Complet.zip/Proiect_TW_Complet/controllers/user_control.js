const { uuid } = require('uuidv4');
const readJSON = require('../util/readJSON');
const fs = require('fs');


const saveUser = (req, res) => {
  const newUser = req.body.user;
  newUser.id = uuid();


  const users = readJSON('./DB/users.json');
  users.push(newUser);

  fs.writeFileSync('./DB/users.json', JSON.stringify(users));

  res.send(newUser);
}

const getUsers = (req, res) => {
  const users = readJSON('./DB/users.json');
  res.send(users);
}

exports.saveUser = saveUser;
exports.getUsers = getUsers;
