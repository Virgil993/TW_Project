function Read_more_europe()
{
    var more_txt = document.getElementById("read_more_europe");
    var btn_txt = document.getElementById("read_more_btn_europe");
    
    if(more_txt.style.display === "none"){
        btn_txt.innerHTML = "Read less";
        more_txt.style.display = "inline";
    }
    else{
        btn_txt.innerHTML = "Read more";
        more_txt.style.display = "none";
        
    }
}
function Read_more_asia()
{
    var more_txt = document.getElementById("read_more_asia");
    var btn_txt = document.getElementById("read_more_btn_asia");
    
    if(more_txt.style.display === "none"){
        btn_txt.innerHTML = "Read less";
        more_txt.style.display = "inline";
    }
    else{
        btn_txt.innerHTML = "Read more";
        more_txt.style.display = "none";
        
    }
}
function Read_more_africa()
{
    var more_txt = document.getElementById("read_more_africa");
    var btn_txt = document.getElementById("read_more_btn_africa");
    
    if(more_txt.style.display === "none"){
        btn_txt.innerHTML = "Read less";
        more_txt.style.display = "inline";
    }
    else{
        btn_txt.innerHTML = "Read more";
        more_txt.style.display = "none";
        
    }
}
function Read_more_america_n()
{
    var more_txt = document.getElementById("read_more_america_n");
    var btn_txt = document.getElementById("read_more_btn_america_n");
    
    if(more_txt.style.display === "none"){
        btn_txt.innerHTML = "Read less";
        more_txt.style.display = "inline";
    }
    else{
        btn_txt.innerHTML = "Read more";
        more_txt.style.display = "none";
        
    }
}

function Read_more_america_s()
{
    var more_txt = document.getElementById("read_more_america_s");
    var btn_txt = document.getElementById("read_more_btn_america_s");
    
    if(more_txt.style.display === "none"){
        btn_txt.innerHTML = "Read less";
        more_txt.style.display = "inline";
    }
    else{
        btn_txt.innerHTML = "Read more";
        more_txt.style.display = "none";
        
    }
}

function Read_more_oceania()
{
    var more_txt = document.getElementById("read_more_oceania");
    var btn_txt = document.getElementById("read_more_btn_oceania");
    
    if(more_txt.style.display === "none"){
        btn_txt.innerHTML = "Read less";
        more_txt.style.display = "inline";
    }
    else{
        btn_txt.innerHTML = "Read more";
        more_txt.style.display = "none";
        
    }
}


function Read_more_antartica()
{
    var more_txt = document.getElementById("read_more_antartica");
    var btn_txt = document.getElementById("read_more_btn_antartica");
    
    if(more_txt.style.display === "none"){
        btn_txt.innerHTML = "Read less";
        more_txt.style.display = "inline";
    }
    else{
        btn_txt.innerHTML = "Read more";
        more_txt.style.display = "none";
        
    }
}

function Read_more_all()
{
    var more_txt = document.getElementById("read_more_all");
    var btn_txt = document.getElementById("read_more_btn_all");
    
    if(more_txt.style.display === "none"){
        btn_txt.innerHTML = "Read less";
        more_txt.style.display = "inline";
    }
    else{
        btn_txt.innerHTML = "Read more";
        more_txt.style.display = "none";
        
    }
}



function generate_europe() {

const ne = {lat: 63.29071047413346, lng:26.44206912341438};
const sw = {lat: 38.10864996886593, lng:-8.144173750618291};
var ptlat = Math.random()*(ne.lat-sw.lat)+sw.lat;
var ptlng = Math.random()*(ne.lng-sw.lng)+sw.lng;
var point = {lat: ptlat,lng: ptlng};
const map = new google.maps.Map(document.getElementById("harta_europe"), {
zoom: 4,
center: point,
});
const marker = new google.maps.Marker({
position: point,
map: map,
});

}


function generate_asia() {
const sw = {lat:31.004667887712746, lng:54.21268536772305};
const ne = {lat: 71.46865673578371,lng: 143.64004940568512};
var ptlat = Math.random()*(ne.lat-sw.lat)+sw.lat;
var ptlng = Math.random()*(ne.lng-sw.lng)+sw.lng;
var point = {lat: ptlat,lng: ptlng};
const map = new google.maps.Map(document.getElementById("harta_asia"), {
zoom: 4,
center: point,
});
const marker = new google.maps.Marker({
position: point,
map: map,
});

}

function generate_africa() {
const sw = {lat:-31.2321998818444, lng:1.5575870392732403};
const ne = {lat: 33.84245342373422, lng: 41.459931292006175};
var ptlat = Math.random()*(ne.lat-sw.lat)+sw.lat;
var ptlng = Math.random()*(ne.lng-sw.lng)+sw.lng;
var point = {lat: ptlat,lng: ptlng};
const map = new google.maps.Map(document.getElementById("harta_africa"), {
zoom: 4,
center: point,
});
const marker = new google.maps.Marker({
position: point,
map: map,
});

}

function generate_america_de_nord() {
const sw = {lat:21.911810826294573,lng: -103.91116269053536};
const ne = {lat: 71.84574037166543, lng:-80.00491238933856};
var ptlat = Math.random()*(ne.lat-sw.lat)+sw.lat;
var ptlng = Math.random()*(ne.lng-sw.lng)+sw.lng;
var point = {lat: ptlat,lng: ptlng};
const map = new google.maps.Map(document.getElementById("harta_america_n"), {
zoom: 4,
center: point,
});
const marker = new google.maps.Marker({
position: point,
map: map,
});

}


function generate_america_de_sud() {
const sw = {lat:-53.185224872875295,lng: -72.62799611414445};
const ne = {lat:9.748472235522268,lng: -36.90466360072167};
var ptlat = Math.random()*(ne.lat-sw.lat)+sw.lat;
var ptlng = Math.random()*(ne.lng-sw.lng)+sw.lng;
var point = {lat: ptlat,lng: ptlng};
const map = new google.maps.Map(document.getElementById("harta_america_s"), {
zoom: 4,
center: point,
});
const marker = new google.maps.Marker({
position: point,
map: map,
});

}


function generate_oceania() {
const sw = {lat:-37.132592049210125, lng:120.10717265473863};
const ne = {lat:-4.29342649637474,lng: 152.29938129067807};
var ptlat = Math.random()*(ne.lat-sw.lat)+sw.lat;
var ptlng = Math.random()*(ne.lng-sw.lng)+sw.lng;
var point = {lat: ptlat,lng: ptlng};
const map = new google.maps.Map(document.getElementById("harta_oceania"), {
zoom: 4,
center: point,
});
const marker = new google.maps.Marker({
position: point,
map: map,
});

}


function generate_antarctica(){
const sw = {lat:-84.11859205837555, lng:-166.09253203942805};
const ne = {lat:-71.39330717255078, lng:166.10459999574613};
var ptlat = Math.random()*(ne.lat-sw.lat)+sw.lat;
var ptlng = Math.random()*(ne.lng-sw.lng)+sw.lng;
var point = {lat: ptlat,lng: ptlng};
const map = new google.maps.Map(document.getElementById("harta_antartica"), {
zoom: 4,
center: point,
});
const marker = new google.maps.Marker({
position: point,
map: map,
});
}

function generate_all(){
const sw = {lat:-84.56880808823242,lng: -171.6182051462604};
const ne = {lat:82.86748564981764, lng:170.21408682463792};
var ptlat = Math.random()*(ne.lat-sw.lat)+sw.lat;
var ptlng = Math.random()*(ne.lng-sw.lng)+sw.lng;
var point = {lat: ptlat,lng: ptlng};
const map = new google.maps.Map(document.getElementById("harta_all"), {
  zoom: 4,
  center: point,
});
const marker = new google.maps.Marker({
  position: point,
  map: map,
});

}

function change_color_of_title()
{    
    var randomColor = Math.floor(Math.random()*16777215).toString(16);
    const titluri = document.getElementsByTagName("h2");
    for(var i=0;i<titluri.length;i++)
        titluri[i].style.color="#"+randomColor;
}

function genereaza_avioane()
{
for (let i = 0; i < 10; i++) {
const img = document.createElement('img');
img.classList.add('avioane_interior');
img.src = "https://image.shutterstock.com/image-vector/airplane-icon-vector-transportation-logo-600w-1283834365.jpg";
const loc = document.getElementById('avioane');
loc.appendChild(img);
}
const loc = document.getElementById('avioane');
loc.style.display = "flex";
loc.style.justifyContent = "center";
const elements = document.getElementsByClassName("avioane_interior");
for(var i = 0;i<elements.length;i++)
{
  elements[i].style.padding = "20px";
  elements[i].style.width = "50px";
  elements[i].style.height = "50px";
}
}

function delete_avion(i){
const av = document.getElementsByClassName("avioane_interior");
if(i>=0 && i<av.length)
{
    var el = document.getElementById("avioane").children;
    el.item(i).remove();
}
}

const keyDownHandler = (event) => {
const digit = getDigit(event.code);
if (!digit)
{    const div = document.getElementById('sageata');
    if (event.code === 'KeyW' && parseInt(window.getComputedStyle(div).top) - 10>-170) {
        div.style.top = (parseInt(window.getComputedStyle(div).top) - 10) + 'px';

      }
      if (event.code === 'KeyS' && parseInt(window.getComputedStyle(div).top) + 10<170) {
        div.style.top = (parseInt(window.getComputedStyle(div).top) + 10) + 'px';

      }
      if (event.code === 'KeyA'&& parseInt(window.getComputedStyle(div).left) - 10>-360) {
        div.style.left = (parseInt(window.getComputedStyle(div).left) - 10) + 'px';
    
      }
      if (event.code === 'KeyD' && parseInt(window.getComputedStyle(div).left) + 10<110) {
        div.style.left = (parseInt(window.getComputedStyle(div).left) + 10) + 'px';
        
      }

    return;
    
  
}
delete_avion(digit);
}


const getDigit = (code) => {
const digit = code.split('Digit')[1];
if (digit)
return digit;

return false;
}

function change_color()
{

const aux = document.getElementById("welcome");
if(aux.style.color ==="red")
aux.style.color = "seagreen";
else
aux.style.color = "red";
}

function change_size_title_to_big()
{
document.getElementById("welcome").style.fontSize = "80px";
}

function change_size_title_to_normal(){
document.getElementById("welcome").style.fontSize = "60px";
}

function change_size_of_icons()
{
const el = document.getElementById("range").value;
const elements = document.querySelectorAll(".avioane_interior");
for(var i=0;i<elements.length;i++)
{
    elements[i].style.width = el.toString()+"px";
    elements[i].style.height = el.toString()+"px";
}
}
const format_show = "First Name Last Name Gender Rating Date";


const firstRegExp = new RegExp(/^[a-z ,.'-]+$/i);


const validInfo = (first, last) => {
console.log(firstRegExp.test(first));
console.log(firstRegExp.test(last));
return firstRegExp.test(first) && firstRegExp.test(last);
}

localStorage.setItem("0",format_show);
function gather_information()
{

var today = new Date();
var dd = String(today.getDate()).padStart(2, '0');
var mm = String(today.getMonth() + 1).padStart(2, '0'); //ianuarie incepe la 0
var yyyy = today.getFullYear();
today = dd + '/' + mm + '/' + yyyy;
const rat = document.getElementsByClassName("avioane_interior");
var fn = document.getElementById("fn_interfata").value.toString();
var ln = document.getElementById("ln_interfata").value.toString();
if(validInfo(fn,ln))
{
const obj = fn+" "+ln+" "+
document.getElementById("gender").value+" "+
rat.length.toString()+" "+today;
localStorage.setItem(localStorage.length.toString(),obj);
}
}
//localStorage.clear();
var breaker = 0;
function show_info()
{
if(breaker === 0)
{
const parinte = document.getElementById("utilizatori");
for(var i=0;i<localStorage.length;i++)
{
    
    const div= document.createElement("div");
    div.classList.add("info_utilizatori");
    var obj = localStorage.getItem(i.toString());
    div.innerHTML =obj;
      parinte.appendChild(div);
    
}
breaker = 1;
}
}
function hide_info()
{
const parinte = document.getElementById("utilizatori");
while(parinte.firstChild)
parinte.removeChild(parinte.lastChild);
breaker = 0;


}

function make_coord()
{
const nx = Math.floor(Math.random() * (2300 - 1800 + 1) + 1800);
const ny = Math.floor(Math.random()* (1600-1200+1)+1200 );
return [nx,ny];
}

function show_coord(event)
{

console.log(event.clientX);
console.log(event.clientY);

}

function move_plane()
{
const el = document.getElementById("test");
var coord = make_coord();
el.style.top = coord[0]+"px";
el.style.left = coord[1]+"px";

}







function hide_photo(event) {
event.target.style.visibility = 'hidden';
if(document.getElementById("check").checked)
event.stopPropagation();
}



function add_listener_poze(){

const poze = document.getElementsByClassName("poze");
for(var i=0;i<poze.length;i++)
poze[i].addEventListener('click',hide_photo,false);
}


function show_photos()
{
const poz = document.querySelectorAll(".poze_container");
for(var i=0;i<poz.length;i++)
if(poz[i].style.visibility === 'hidden')
    poz[i].style.visibility = 'visible';
const poz2 = document.getElementsByClassName("poze");
for(var i=0;i<poz2.length;i++)
if(poz2[i].style.visibility === 'hidden')
    poz2[i].style.visibility = 'visible';
}

function hello_continent(event)
{
if(event.currentTarget.classList[0] ==="title")
alert("Welcome to "+ event.currentTarget.innerHTML);

}


function alert_del_photo()
{
alert("You have removed 1 photo");
}





window.onload = () =>{
document.getElementById("welcome").onclick = change_color;
document.getElementById("welcome").onmouseover = change_size_title_to_big;
document.getElementById("welcome").onmouseout = change_size_title_to_normal;
document.addEventListener("keydown", keyDownHandler);
add_listener_poze();
Read_more_europe();
Read_more_asia();
Read_more_africa();
Read_more_america_n();
Read_more_america_s();
Read_more_oceania();
Read_more_antartica();
Read_more_all();
generate_europe();
generate_asia();
generate_africa();
generate_america_de_nord();
generate_america_de_sud();
generate_oceania();
generate_antarctica();
generate_all();
setInterval(change_color_of_title,1000);
setTimeout(genereaza_avioane,2000);
setInterval(change_size_of_icons,1);
setInterval(move_plane,2000);
document.getElementById("check").checked = true;

//localStorage.clear();

}







