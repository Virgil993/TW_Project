const fs = require('fs');

const readJSON = (fileName) => {
  // 
  const rawData = fs.readFileSync(fileName);
  const parsedData = JSON.parse(rawData);

  return parsedData;
}

module.exports = readJSON;