const express = require('express');
const app = express();
const user_route = require('./user_route/route');

app.listen(5000)

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true }));

app.use('/static', express.static('resources'));

app.use('/users',user_route);

app.get('/',(req,res) => {
    res.redirect('/static/Proiect_Register.html')
})

app.get('/welcome', (req,res) => {
    res.redirect('/static/Proiect_Welcome.html')
})

app.get('/register',(req,res)=>{
    res.redirect('/static/Proiect_Register.html')
})


